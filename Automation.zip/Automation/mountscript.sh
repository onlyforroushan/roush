#!/bin/sh
echo "enter server name: "
read server
echo "enter user name "
read user
echo "enter password"
read -s password
echo "enter resource group "
read rg
echo "Generating key for the storage"
rm -rf /tmp/mount.sh
rm -rf /tmp/key.txt
touch /tmp/key.txt
chmod 777 /tmp/key.txt
storage=$( echo "$rg" | sed 's/rg/sfssa/' )
az storage account keys list --account-name $storage | grep value | awk '{print $2}' | sed 's/\"//g' | head -n 1 > /tmp/key.txt
echo "key is:"
cat /tmp/key.txt
echo "sending key to destination server"
#sshpass -p $password scp -r key.txt $user@$server:~
echo "Creating storage and fileshare from rg:"
fs=$( echo "$rg" | sed 's/rg/fs/' )
echo "below is storage and fileshare respectively"
echo $storage
echo $fs
key=$( cat /tmp/key.txt )
touch /tmp/mount.sh
chmod 777 /tmp/mount.sh
cat >/tmp/mount.sh <<EOL
#!/bin/sh
sudo mkdir /backup
if [ ! -d "/etc/smbcredentials" ]; then
sudo mkdir /etc/smbcredentials
fi
if [ ! -f "/etc/smbcredentials/storageaccount.cred" ]; then
    sudo bash -c 'echo "username=storageaccount" >> /etc/smbcredentials/storageaccount.cred'
    sudo bash -c 'echo "password=storagekey" >> /etc/smbcredentials/storageaccount.cred'
fi
sudo chmod 600 /etc/smbcredentials/storageaccount.cred
sudo bash -c 'echo "//storageaccount.file.core.windows.net/fileshare /backup cifs
nofail,vers=3.0,credentials=/etc/smbcredentials/storageaccount.cred,dir_mode=0777,file_mode=0777,serverino" >> /etc/fstab'
sudo mount -t cifs //storageaccount.file.core.windows.net/fileshare /backup -o vers=3.0,credentials=/etc/smbcredentials/storageaccount.cred,dir_mode=0777,file_mode=0777,serverino
EOL
sed -i "s|storageaccount|${storage}|g" /tmp/mount.sh
sed -i "s|fileshare|${fs}|g" /tmp/mount.sh
sed -i "s|storagekey|${key}|g" /tmp/mount.sh

sshpass -p $password scp -r /tmp/key.txt $user@$server:~
sshpass -p $password scp -r /tmp/mount.sh $user@$server:~
