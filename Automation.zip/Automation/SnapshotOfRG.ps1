#########Author- roushan.ku (1704542)#############
#########Takes snapshot of all VMs in RG #########
#########Uses tag name & value for RG list #######
#########Deletes snapshots older than 4 Days######

# Ensures you do not inherit an AzContext in your runbook
Disable-AzContextAutosave –Scope Process

#Creating RunAs Connection
$Conn = Get-AutomationConnection -Name AzureRunAsConnection
Connect-AzAccount -ServicePrincipal -Tenant $Conn.TenantID `
-ApplicationId $Conn.ApplicationID -CertificateThumbprint $Conn.CertificateThumbprint

#Creating Context for this Subscription
$AzureContext = Select-AzSubscription -SubscriptionId $Conn.SubscriptionID
Write-Output "Getting list of all RGs, which has tag name and value as SNAP."
$RG_LIST = (Get-AzResourceGroup -Tag @{ "snap"="snap" } -AzContext $AzureContext).ResourceGroupName


Write-Output "List of RGs are: " $RG_LIST
foreach($RG_NAME in $RG_LIST) {
		$vmInfo = Get-AzVM -ResourceGroupName $RG_NAME
		$rg=$RG_NAME
		$resourceGroupName = $RG_NAME
		$bk="bkp"
		$rgbkp=$rg + $bk

		Write-Output "Deleting Daily Snapshots older than 4 days"
		$snapshotnames2 = (Get-AzSnapshot -ResourceGroupName $rgbkp | ?{($_.TimeCreated) -lt ([datetime]::UtcNow.AddDays(-4))}).Name | Select-String -Pattern "Daily"
        Write-Output $snapshotnames2
		foreach($snapnames in $snapshotnames2)
            {
				Write-Output "Deleting snapshot: " $snapnames
                Get-AzSnapshot -ResourceGroupName $rgbkp -SnapshotName $snapnames | remove-azsnapshot -force
            }
			
		$VM_NAMES = $vmInfo.Name
		foreach($VM in $VM_NAMES) {
		Write-Output "RG is" $RG_NAME
		Write-Output "VM is: " $VM
		$timestamp = Get-Date -f MM-dd-yyyy_HH_mm_ss
		$snapshotName = $VM + "_OS_Disk_Daily_" + $timestamp
		$location = (Get-AzVM -ResourceGroupName $RG_NAME -Name $VM).Location
		$snapshot =  New-AzSnapshotConfig -SourceUri (Get-AzVM -ResourceGroupName $RG_NAME -Name $VM).StorageProfile.OsDisk.ManagedDisk.Id -Location $location  -CreateOption copy
		Write-Output "Creating OS Snapshot: " $snapshotName
		New-AzSnapshot -Snapshot $snapshot -SnapshotName $snapshotName -ResourceGroupName $rgbkp

				if((Get-AzVM -ResourceGroupName $RG_NAME -Name $VM).StorageProfile.DataDisks.Count -ge 1){
					for($i=0; $i -le (Get-AzVM -ResourceGroupName $RG_NAME -Name $VM).StorageProfile.DataDisks.Count - 1; $i++){
						#$snapshots = (Get-AzVM -ResourceGroupName $RG_NAME -Name $VM).StorageProfile.DataDisks[$i].Name
                        $snapshotName = $VM + "_DATA_Disk_Daily_" + "_Number_" + ($i + 1) + "_" + $timestamp
						Write-Output "Creating DataDisk Snapshot: " $snapshotName
						$snapshot =  New-AzSnapshotConfig -SourceUri (Get-AzVM -ResourceGroupName $RG_NAME -Name $VM).StorageProfile.DataDisks[$i].ManagedDisk.Id -Location $location  -CreateOption copy
						New-AzSnapshot -Snapshot $snapshot -SnapshotName $snapshotName -ResourceGroupName $rgbkp 
						}
					}
				else{
						Write-Host $VM + " doesn't have any additional data disk."
				}
		}

}