#!/bin/sh
#full backup
timestamp()
{
 date +"%Y-%m-%d %T.%3N"
}

tech="Hadoop"
backuptype="FullBackup"
namespace=$1
kinit -k -t /ignio/hbase/etc/security/hbase.service.keytab hbase/"$HOSTNAME".inignio.com@$(cat /etc/krb5.conf | grep -m1 realm | cut -b 17-30)
DATE=`date '+%Y%m%d%H%M%S'`

if [ $? -eq 0 ]; then
        echo "$(timestamp)|${tech}|${backuptype}|INFO|/ignio/hdfs_backup/full_hadoop_backup.sh|Full Database Backup Started for tenant ${namespace} with current epocTime, i.e. $DATE"
else
    echo "$(timestamp)|${tech}|${backuptype}|ERROR|/ignio/hdfs_backup/full_hadoop_backup.sh|Full Database Backup Failed. Unable to update date"
        exit 1
fi


epocTime=`date +%s%3N`

#echo "$(timestamp)|${tech}|${backuptype}|INFO|/ignio/hdfs_backup/full_hadoop_backup.sh|New backup has been scheduled at:"

echo "/bin/sh /ignio/hdfs_backup/full_hadoop_backup.sh ${namespace} >> /ignio/log/fullbackuphbase.log 2>&1" | at tomorrow

store_path=/ignio/hdfs_backup/${namespace}/backup/fullbackup/fullbackup_${DATE}
mkdir -p ${store_path}
mkdir -p /backup/${namespace}/backup/fullbackup/
mkdir -p /backup/${namespace}/backup/incbackup/
chmod -R 777 ${store_path}
echo "list '"$namespace":.*' " | /ignio/hbase/bin/hbase shell &> /ignio/hdfs_backup/${namespace}/ListOutput
cat /ignio/hdfs_backup/${namespace}/ListOutput | grep "^"${namespace}":" >/ignio/hdfs_backup/${namespace}/ListOfTable

/ignio/hadoop-hdfs/bin/hdfs dfs -mkdir -p /backup/${namespace}/fullbackup_${DATE}  > /dev/null 2>&1

while read line; do
        tableName=`echo $line | cut -d':' -f2`
        /ignio/hbase/bin/hbase org.apache.hadoop.hbase.mapreduce.Export $line hdfs:///backup/${namespace}/fullbackup_${DATE}/${tableName}/  &> /dev/null
if [ $? == 1 ]; then
   echo "$(timestamp)|${tech}|${backuptype}|INFO|/ignio/hdfs_backup/full_hadoop_backup.sh|$line Backed-Up Successfully"
else
echo "$(timestamp)|${tech}|${backuptype}|ERROR|/ignio/hdfs_backup/full_hadoop_backup.sh|$line Backup failed"
exit 1
fi
        /ignio/hadoop-hdfs/bin/hdfs dfs -chmod -R 777 /backup/${namespace}/fullbackup_${DATE}/ > /dev/null 2>&1
       /ignio/hadoop-hdfs/bin/hdfs dfs -get /backup/${namespace}/fullbackup_${DATE}/${tableName} ${store_path} > /dev/null 2>&1
done < /ignio/hdfs_backup/${namespace}/ListOfTable

echo "$(timestamp)|${tech}|${backuptype}|INFO|/ignio/hdfs_backup/full_hadoop_backup.sh|Backup completed successfully for ${namespace} at $DATE "

echo ${epocTime} > ${store_path}/epocTime

/ignio/hadoop-hdfs/bin/hdfs dfs -rm -r /backup/${namespace}/fullbackup_${DATE}/ > /dev/null 2>&1


cp -r ${store_path} /backup/${namespace}/backup/fullbackup

cd ${store_path}/../
rm -rf /ignio/hdfs_backup/${namespace}/backup/fullbackup/fullbackup_${DATE} > /dev/null 2>&1

cd /backup/${namespace}/backup/fullbackup
rm -rf `ls -t | awk 'NR>4'` > /dev/null 2>&1

