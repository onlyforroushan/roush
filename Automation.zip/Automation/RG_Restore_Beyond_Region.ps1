#########RESTORE BEYOND REGION###########
$dr_rg_name = "asuse11dopsq1rgbkp"
$storageAccountName = "asuse11dopsq1rgbkpbkp"
$destContainer = "drcontainer"
Select-AzureRmSubscription -SubscriptionName DigitateSaasInternal
$context = (Get-AzStorageAccount -ResourceGroupName $dr_rg_name -AccountName $storageAccountName).context
$storageAccountNamekey = (Get-AzStorageAccountKey -Name $storageAccountName -ResourceGroupName $dr_rg_name).value[0]
#$snapshots = Get-AzSnapshot -ResourceGroupName $dr_rg_name | ?{($_.TimeCreated) -gt ([datetime]::UtcNow.Addhours(-12))}
$osvhdfiles = Get-AzureStorageBlob -Container "drcontainer" -Context $context | ?{($_.LastModified) -gt ([datetime]::UtcNow.Addhours(-23))} | ?{($_.Name) -match "OS"} | ?{($_.Name) -match ".vhd"}
$storageaccountid = Get-AzStorageAccount -Name $storageAccountName -ResourceGroupName $dr_rg_name
$NOW=$(Get-Date -Format "MM_dd_yyyy_HH_mm")
$snapshots = Get-AzSnapshot -ResourceGroupName $dr_rg_name | ?{($_.TimeCreated) -gt ([datetime]::UtcNow.Addhours(-12))}
foreach ($osdisksnapshot in $osvhdfiles) {
    $vhdname = $($osdisksnapshot.name).Substring(0,$($osdisksnapshot.name).Length-0)
    #Create Managed Disk
    $diskuri = "https://$($storageAccountName).blob.core.windows.net/$($destContainer)/$($vhdname)"
    $storageType = 'Premium_LRS'
	#$storageType = (Get-AzStorageAccount -Name $storageAccountName -ResourceGroupName $dr_rg_name).Sku.Name
	$location = (Get-AzStorageAccount -Name $storageAccountName -ResourceGroupName $dr_rg_name).Location
	$VM_NAME=$vhdname.Split('_')[0]

##########################Finding VM SIZE##################################

if ($VM_NAME -match 'anly') 
{
    $VM_SIZE="Standard_F4s"
	#$NIC_NAME=$VM_NAME.Substring(0,$VM_NAME.Length-2) + "01nic01dr"
	$NIC_NAME=$VM_NAME + "nic01dr"
	$NIC_ID=(Get-AzureRmNetworkInterface -Name $NIC_NAME -ResourceGroupName $dr_rg_name).Id
	$disk_name = $VM_NAME+"_OS_"+$NOW
	Write-Output "This is anlytics"
	Write-Output "VM Size is: "$VM_SIZE
	Write-Output "Disk name is: " $disk_name
	Write-Output "NIC name is: " $NIC_NAME
	Write-Output "NIC Id is: " $NIC_ID
} elseif ($VM_NAME -match 'cht')
{
	$VM_SIZE="Standard_F16s"
	#$NIC_NAME=$VM_NAME.Substring(0,$VM_NAME.Length-2) + "01nic01dr"
	$NIC_NAME=$VM_NAME + "nic01dr"
	$NIC_ID=(Get-AzureRmNetworkInterface -Name $NIC_NAME -ResourceGroupName $dr_rg_name).Id
	$disk_name = $VM_NAME+"_OS_"+$NOW
	Write-Output "This is cheatah"
	Write-Output "VM Size is: "$VM_SIZE
	Write-Output "Disk name is: " $disk_name
	Write-Output "NIC name is: " $NIC_NAME
	Write-Output "NIC Id is: " $NIC_ID
} elseif ($VM_NAME -match 'neo')
{
	$VM_SIZE="Standard_E4s_v3"
	#$NIC_NAME=$VM_NAME.Substring(0,$VM_NAME.Length-2) + "01nic01dr"
	$NIC_NAME=$VM_NAME + "nic01dr"
	$NIC_ID=(Get-AzureRmNetworkInterface -Name $NIC_NAME -ResourceGroupName $dr_rg_name).Id
	$disk_name = $VM_NAME+"_OS_"+$NOW
	Write-Output "This is neo4j"
	Write-Output "VM Size is: "$VM_SIZE
	Write-Output "Disk name is: " $disk_name
	Write-Output "NIC name is: " $NIC_NAME
	Write-Output "NIC Id is: " $NIC_ID
} elseif ($VM_NAME -match 'bfl')
{
	$VM_SIZE="Standard_E8s_v3"
	#$NIC_NAME=$VM_NAME.Substring(0,$VM_NAME.Length-2) + "01nic01dr"
	$NIC_NAME=$VM_NAME + "nic01dr"
	$NIC_ID=(Get-AzureRmNetworkInterface -Name $NIC_NAME -ResourceGroupName $dr_rg_name).Id
	$disk_name = $VM_NAME+"_OS_"+$NOW
	Write-Output "This is butterfly"
	Write-Output "VM Size is: "$VM_SIZE
	Write-Output "Disk name is: " $disk_name
	Write-Output "NIC name is: " $NIC_NAME
	Write-Output "NIC Id is: " $NIC_ID
} elseif ($VM_NAME -match 'jump')
{
	$VM_SIZE="Standard_B2ms"
	#$NIC_NAME=$VM_NAME.Substring(0,$VM_NAME.Length-2) + "01nic01dr"
	$NIC_NAME=$VM_NAME + "nic01dr"
	$NIC_ID=(Get-AzureRmNetworkInterface -Name $NIC_NAME -ResourceGroupName $dr_rg_name).Id
	$disk_name = $VM_NAME+"_OS_"+$NOW
	Write-Output "This is jump"
	Write-Output "VM Size is: "$VM_SIZE
	Write-Output "Disk name is: " $disk_name
	Write-Output "NIC name is: " $NIC_NAME
	Write-Output "NIC Id is: " $NIC_ID
} else {
	Write-Output "This is: " $VM_NAME
	#$VM_SIZE="Standard_B2ms"
	#$NIC_NAME=$VM_NAME.Substring(0,$VM_NAME.Length-2) + "01nic01dr"
	#$NIC_NAME=$VM_NAME + "nic01dr"
	#$NIC_ID=(Get-AzureRmNetworkInterface -Name $NIC_NAME -ResourceGroupName $dr_rg_name).Id
	$disk_name = $VM_NAME+"_OS_"+$NOW
	#Write-Output "VM Size is: "$VM_SIZE
	# Write-Output "Disk name is: " $disk_name
	# Write-Output "NIC name is: " $NIC_NAME
	# Write-Output "NIC Id is: " $NIC_ID
	
$confirmation = Read-Host "This is not Cheatah, Butterfly, Analytics, Jump. Are you Sure You Want To Proceed, press y to confirm yes "
$NIC_NAME = Read-Host "Please enter nic name for this vm, if you have any "
$VM_SIZE = Read-Host "Please enter VM_SIZE for this vm, if you have any "
$NIC_ID=(Get-AzureRmNetworkInterface -Name $NIC_NAME -ResourceGroupName $dr_rg_name).Id

}

############################################################
	#$disk_name = $VM_NAME+"_OS_"+$NOW
	#$vnet = $dr_rg_name.TrimEnd("rgbkp")+"vnetdr"
	#$subnet = $dr_rg_name.TrimEnd("rgbkp")+"chtsubnetdr"
	#$subnet = (Get-AzureRmVirtualNetwork -Name $vnet -ResourceGroupName $dr_rg_name).Subnets.Name -match "cht"
    try {
        Write-Output "Creating managed disk: $disk_name"
        $diskConfig = New-AzDiskConfig -AccountType $storageType -Location $location -CreateOption Import -StorageAccountId $storageaccountid.id -SourceUri $diskuri
        New-AzDisk -Disk $diskConfig -ResourceGroupName $dr_rg_name -DiskName $disk_name -ErrorAction stop
        Write-Output "managed disk: $disk_name created"
    } catch {
        Write-output "Error Creating managed disk: $disk_name"
        $_
    }
	Start-Sleep 20
	$osdiskid=(Get-AzureRmDisk -ResourceGroupName $dr_rg_name -DiskName $disk_name).Id
	#$vmConfig = New-AzVMConfig -VMName $VM_NAME -VMSize "Standard_A2"
	
	# $vmConfig = New-AzVMConfig -VMName $VM_NAME -VMSize $VM_SIZE
	# $vm = Add-AzVMNetworkInterface -VM $vmConfig -Id $NIC_ID
	# $SUBNET_ID=(Get-AzureRmNetworkInterface -Name $NIC_NAME -ResourceGroupName $dr_rg_name).IpConfigurations.subnet.id
	# #$vm = Set-AzVMOSDisk -VM $vm -ManagedDiskId $osdisksnapshot.Id -StorageAccountType $storageType -CreateOption Attach
	# $vm = Set-AzVMOSDisk -VM $vm -ManagedDiskId $osdiskid -CreateOption Attach -Linux
	# New-AzVM -ResourceGroupName $dr_rg_name -Location $location -VM $vm
 


	$VirtualMachine = New-AzureRmVMConfig -VMName $VM_NAME -VMSize $VM_SIZE
	#$VirtualMachine = Set-AzureRmVMOperatingSystem -VM $VirtualMachine -ComputerName $VM_NAME -Linux
	$VirtualMachine = Add-AzureRmVMNetworkInterface -VM $VirtualMachine -Id $NIC_ID
	$VirtualMachine = Set-AzureRmVMOSDisk -VM $VirtualMachine -ManagedDiskId $osdiskid -CreateOption Attach -Linux
	
	New-AzureRmVM -ResourceGroupName $dr_rg_name -Location $location -VM $VirtualMachine -Verbose
	
	
}


$datavhdfiles = Get-AzureStorageBlob -Container "drcontainer" -Context $context | ?{($_.LastModified) -gt ([datetime]::UtcNow.Addhours(-23))} | ?{($_.Name) -match "DATA"} | ?{($_.Name) -match ".vhd"}

foreach ($datadisksnapshot in $datavhdfiles) {
	
    $vhdname = $($datadisksnapshot.name).Substring(0,$($datadisksnapshot.name).Length-0)
	$VM_NAME=$vhdname.Split('_')[0]
	$disk_name = $VM_NAME+"_DATA_lun_"+$NOW
    #Create Managed Disk
    $diskuri = "https://$($storageAccountName).blob.core.windows.net/$($destContainer)/$($vhdname)"
    $storageType = 'Premium_LRS'
	#$storageType = (Get-AzStorageAccount -Name $storageAccountName -ResourceGroupName $dr_rg_name).Sku.Name
	$location = (Get-AzStorageAccount -Name $storageAccountName -ResourceGroupName $dr_rg_name).Location
	
	try {
        Write-Output "Creating data disk: $disk_name"
        $diskConfig = New-AzDiskConfig -AccountType $storageType -Location $location -CreateOption Import -StorageAccountId $storageaccountid.id -SourceUri $diskuri
        New-AzDisk -Disk $diskConfig -ResourceGroupName $dr_rg_name -DiskName $disk_name -ErrorAction stop
        Write-Output "managed disk: $disk_name created"
    } catch {
        Write-output "Error Creating managed disk: $disk_name"
        $_
    }
	$datadiskid=(Get-AzureRmDisk -ResourceGroupName $dr_rg_name -DiskName $disk_name).Id
	sleep 2
	echo "Attaching Data disk to VM $VM_NAME "
	Add-AzureRmVMDataDisk -VM $VM_NAME -Name $disk_name -CreateOption Attach -ManagedDiskId $datadiskid
	sleep 2
	Update-AzureRmVm -ResourceGroupName $dr_rg_name -VM $VM_NAME
	}

# foreach ($osdisksnapshot in $osvhdfiles) {
    # $vhdname = $($osdisksnapshot.name).Substring(0,$($osdisksnapshot.name).Length-0)
    # #Create Managed Disk
    # $diskuri = "https://$($storageAccountName).blob.core.windows.net/$($destContainer)/$($vhdname)"
    # $storageType = 'Premium_LRS'
	# #$storageType = (Get-AzStorageAccount -Name $storageAccountName -ResourceGroupName $dr_rg_name).Sku.Name
	# $location = (Get-AzStorageAccount -Name $storageAccountName -ResourceGroupName $dr_rg_name).Location
	# $VM_NAME=$vhdname.Split('_')[0]
# }