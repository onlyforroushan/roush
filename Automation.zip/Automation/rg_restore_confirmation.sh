#!/bin/sh

#######################################USER INPUT#################################################
RG_NAME=asuse11dopsq1rg   ##Name of the RG, from where above VM belongs, ex- asuse11dopsq1rg
RG_SNAP=$RG_NAME"bkp"     ##change it if and only if snapshot rg is different than bkp RG. Make sure they are in same region.
##################################################################################################

############################################ LIMITATION ##########################################
##################################### LVM VMs NOT SUPPORTED ######################################
##################################################################################################
SECONDS=0
DATE=`date '+%Y%m%d%H%M%S'`
ADATE=`date`
echo "Activity started on: " $ADATE

echo "Enter 1 for DigitateSaaSCustomer (7fda1fea-1ecc-4a7f-8e44-d9de4130541e) Subscription"
echo "Enter 2 for DigitateSaaSInternal (0a2449ac-4fe3-4900-842b-d162e1d7bc09) Subscription"
echo "Enter 3 for DigitateSaaSDemo (e01e2545-a86a-4313-9816-e36ae1a23a07) Subscription"
echo "Enter 4 for DigitateSaaSCP (4120e5f7-d243-428d-ad7f-b5c7f5ce37ea) Subscription"
read NUMBER
case "$NUMBER" in
   "1") subscriptionId="7fda1fea-1ecc-4a7f-8e44-d9de4130541e"
   ;;
   "2") subscriptionId="0a2449ac-4fe3-4900-842b-d162e1d7bc09"
   ;;
   "3") subscriptionId="e01e2545-a86a-4313-9816-e36ae1a23a07"
   ;;
   "4") subscriptionId="4120e5f7-d243-428d-ad7f-b5c7f5ce37ea"
   ;;
esac

echo "Subscription ID  you chose is: " $subscriptionId
az account set --subscription $subscriptionId

VM_LIST=$(az vm list   --resource-group $RG_NAME --query [].name -o tsv)


##########################################      CONFIRMATION PROMPT    #############################################

while IFS= read -r line1
do
VM_NAME=$line1
echo -e ""
echo "Details of VM: " $VM_NAME
echo ""


OS_DISK=$(az vm show   --resource-group $RG_NAME --name=$VM_NAME --query "storageProfile.osDisk.name" -o tsv)
DT_DISK=$(az vm show   --resource-group $RG_NAME --name=$VM_NAME --query "storageProfile.dataDisks[].name" -o tsv 2>/dev/null)
OS_SKUN=$(az disk show --resource-group $RG_NAME --name $OS_DISK --query sku.name -o tsv)
DT_SKUN=$(az disk show --resource-group $RG_NAME --name $DT_DISK --query sku.name -o tsv 2>/dev/null)
OS_SIZE=$(az disk show --resource-group $RG_NAME --name $OS_DISK --query diskSizeGb -o tsv)
DT_SIZE=$(az disk show --resource-group $RG_NAME --name $DT_DISK --query diskSizeGb -o tsv 2>/dev/null)
OS_SNAP=$(az snapshot list --resource-group $RG_SNAP  --query [].name -o tsv | grep $VM_NAME"_OS_Disk_Daily_" | tail -n 1)
OS_SNAP_ID=$(az snapshot show --resource-group $RG_SNAP --name $OS_SNAP --query [id] -o tsv)
DT_SNAP=$(az snapshot list --resource-group $RG_SNAP  --query [].name -o tsv | grep $VM_NAME"_DATA_Disk_Daily__Number_1" | tail -n 1 2>/dev/null)
DT_SNAP_ID=$(az snapshot show --resource-group $RG_SNAP --name $DT_SNAP --query [id] -o tsv 2>/dev/null)
OS_DISK_NEW=$VM_NAME"_OS_DISK_"$DATE
DT_DISK_NEW=$VM_NAME"_DT_DISK_"$DATE


echo "OS   DISK NAME: " $OS_DISK
echo "DATA DISK NAME: " $DT_DISK
echo "OS   SKU  NAME: " $OS_SKUN
echo "DATA SKU  NAME: " $DT_SKUN
echo "OS   DISK SIZE: " $OS_SIZE
echo "DATA DISK SIZE: " $DT_SIZE
echo "OS SNAPSHOT ID: " $OS_SNAP_ID
echo "DT SNAPSHOT ID: " $DT_SNAP_ID
echo "NEW   OS  DISK: " $OS_DISK_NEW
echo "NEW  DATA DISK: " $DT_DISK_NEW
echo ""
done <<< "$VM_LIST"


elapsedseconds=$SECONDS
echo "Time elapsed in gathering above info is: " $elapsedseconds " seconds"
echo ""

read -p "Please enter 'Y' if above value is Correct. Else EXIT " -n 1 -r
echo -e ""
if [[ ! $REPLY =~ ^[Yy]$ ]]
then
    exit 1
fi

##############################################   EOD OF CONFIRMATION   #############################################

SECONDS=0

while IFS= read -r line
do
VM_NAME=$line
echo -e ""
echo "VM Name is: " $VM_NAME
echo -e ""

OS_DISK=$(az vm show   --resource-group $RG_NAME --name=$VM_NAME --query "storageProfile.osDisk.name" -o tsv)
DT_DISK=$(az vm show   --resource-group $RG_NAME --name=$VM_NAME --query "storageProfile.dataDisks[].name" -o tsv 2>/dev/null)
OS_SKUN=$(az disk show --resource-group $RG_NAME --name $OS_DISK --query sku.name -o tsv)
DT_SKUN=$(az disk show --resource-group $RG_NAME --name $DT_DISK --query sku.name -o tsv 2>/dev/null)
OS_SIZE=$(az disk show --resource-group $RG_NAME --name $OS_DISK --query diskSizeGb -o tsv)
DT_SIZE=$(az disk show --resource-group $RG_NAME --name $DT_DISK --query diskSizeGb -o tsv 2>/dev/null)
OS_SNAP=$(az snapshot list --resource-group $RG_SNAP  --query [].name -o tsv | grep $VM_NAME"_OS_Disk_Daily_" | tail -n 1)
OS_SNAP_ID=$(az snapshot show --resource-group $RG_SNAP --name $OS_SNAP --query [id] -o tsv)
DT_SNAP=$(az snapshot list --resource-group $RG_SNAP  --query [].name -o tsv | grep $VM_NAME"_DATA_Disk_Daily__Number_1" | tail -n 1 2>/dev/null)
DT_SNAP_ID=$(az snapshot show --resource-group $RG_SNAP --name $DT_SNAP --query [id] -o tsv 2>/dev/null)
OS_DISK_NEW=$VM_NAME"_OS_DISK_"$DATE
DT_DISK_NEW=$VM_NAME"_DT_DISK_"$DATE



echo "OS   DISK NAME: " $OS_DISK
echo "DATA DISK NAME: " $DT_DISK
echo "OS   SKU  NAME: " $OS_SKUN
echo "DATA SKU  NAME: " $DT_SKUN
echo "OS   DISK SIZE: " $OS_SIZE
echo "DATA DISK SIZE: " $DT_SIZE
echo "OS SNAPSHOT ID: " $OS_SNAP_ID
echo "DT SNAPSHOT ID: " $DT_SNAP_ID
echo "NEW   OS  DISK: " $OS_DISK_NEW
echo "NEW  DATA DISK: " $DT_DISK_NEW
echo ""

echo -e "Stopping VM: " $VM_NAME
az vm stop --resource-group $RG_NAME --name $VM_NAME


az disk create --resource-group $RG_NAME --name $OS_DISK_NEW --sku $OS_SKUN --size-gb $OS_SIZE --source $OS_SNAP_ID
sleep 5
az disk create --resource-group $RG_NAME --name $DT_DISK_NEW --sku $OS_SKUN --size-gb $DT_SIZE --source $DT_SNAP_ID 2>/dev/null

echo "Detaching DATA DISK: "
az vm disk detach --resource-group $RG_NAME --vm-name $VM_NAME --name $DT_DISK 2>/dev/null

sleep 10
echo "Attaching New OS disk to VM: " $VM_NAME
az vm update --resource-group $RG_NAME -n $VM_NAME --os-disk $OS_DISK_NEW
sleep 10
echo "Attaching New DATA Disk to VM: " $VM_NAME
az vm disk attach --resource-group $RG_NAME --vm-name $VM_NAME --name $DT_DISK_NEW 2>/dev/null

sleep 10
echo -e "Starting VM: " $VM_NAME
az vm start --resource-group $RG_NAME --name $VM_NAME --no-wait
echo "VM " $VM_NAME " Restored!"

done <<< "$VM_LIST"

elapsedseconds1=$SECONDS
echo "All tenants were restored in " $elapsedseconds1 " seconds"

BDATE=`date`
echo "Activity finished on: " $BDATE
