#!/bin/sh
#az login
read -p "Please enter 'Y' if login was successful. " -n 1 -r
echo -e ""
if [[ ! $REPLY =~ ^[Yy]$ ]]
then
    exit 1
fi
echo -e ""
echo "Enter 1 for DigitateSaaS (7fda1fea-1ecc-4a7f-8e44-d9de4130541e) Subscription"
echo "Enter 2 for DigitateSaaSInternal (0a2449ac-4fe3-4900-842b-d162e1d7bc09) Subscription"
echo "Enter 3 for DigitateSaaSDemo (e01e2545-a86a-4313-9816-e36ae1a23a07) Subscription"
echo "Enter 4 for DigitateSaaSCP (4120e5f7-d243-428d-ad7f-b5c7f5ce37ea) Subscription"
read NUMBER
case "$NUMBER" in
   "1") subscriptionId="7fda1fea-1ecc-4a7f-8e44-d9de4130541e"
   ;;
   "2") subscriptionId="0a2449ac-4fe3-4900-842b-d162e1d7bc09"
   ;;
   "3") subscriptionId="e01e2545-a86a-4313-9816-e36ae1a23a07"
   ;;
   "4") subscriptionId="4120e5f7-d243-428d-ad7f-b5c7f5ce37ea"
   ;;
esac
echo "Subscription ID  you chose is: " $subscriptionId
az account set --subscription $subscriptionId
echo "Enter RG: "
read RG
echo "RG is: " $RG
CONCAT_RG=${RG::-2}
VNET_NAME=$CONCAT_RG"vnet"
echo "VNET is: " $VNET_NAME
OLD_PGSQL=$CONCAT_RG"pgsql"
echo "OLD PGSQL is: " $OLD_PGSQL
NEW_PGSQL=$CONCAT_RG"pgsql""4"
echo "NEW PGSQL is: " $NEW_PGSQL
adminuser=azureignio
echo "Admin User is: " $adminuser
adminpassword=PW4dopsqazuredb
echo "Admin password is: " $adminpassword
PGSQL_SKU=MO_Gen5_2
echo "SKU for pgsql will be: " $PGSQL_SKU
PGSQL_Version=11
echo "Version for pgsql will be: " $PGSQL_Version
location=$(az postgres server list -g $RG --query "[?name=='$OLD_PGSQL'].{Name:name,  admin:location}" -o tsv | awk '{print $2}')
echo "Location is: " $location
time_variable=$(date +"%H_%M")
Service_Name="$RG$time_variable"
echo "Your new DMS service will be: " $Service_Name
DMS_SKU_NAME=Premium_4vCores
echo "DMS SKU will be: " $DMS_SKU_NAME

SUBNET_ID=$(az network vnet subnet list --resource-group $RG --vnet-name $VNET_NAME --query [].id -o tsv | grep -v agw)
echo "Subnet IDs are: "
echo $SUBNET_ID

Available_IP=$(az network vnet show -g $RG -n $VNET_NAME --query addressSpace.addressPrefixes -o tsv)
Available_IP_Prefix=${Available_IP%.*}
echo "Your IP Address prefix will be: " $Available_IP_Prefix
echo -e ""

read -p "Please enter 'Y' if above value is correct, else exit. " -n 1 -r
echo -e ""
if [[ ! $REPLY =~ ^[Yy]$ ]]
then
    exit 1
fi

echo "Creating subnet with the name as DMSSubnet."
az network vnet subnet create -n DMSSubnet --vnet-name asuse11dopsq1vnet -g asuse11dopsq1rg --address-prefixes "$Available_IP_Prefix.0/28" --service-endpoints "Microsoft.Sql"
sleep 10
echo "Creating PGSQL-11"
az postgres server create --resource-group $RG --name $NEW_PGSQL --location $location --admin-user $adminuser --admin-password $adminpassword --sku-name $PGSQL_SKU --version $PGSQL_Version --geo-redundant-backup Enabled --storage-size 512000 --backup-retention 7 --auto-grow Disabled --ssl-enforcement Enabled --public-network-access Enabled

i=1
rulename=subnetrulenumber
while IFS= read -r line
do
   echo "Updating Subnet ID: " $line
   rule=$rulename$i
   az postgres server vnet-rule create -g $RG -s $NEW_PGSQL -n $rule --subnet $line
   i=$(($i + 1))
done <<< "$SUBNET_ID"

echo "Allowing Firewall IP on New PGSQL"
az postgres server firewall-rule create -g $RG -s $NEW_PGSQL -n allowiprange --start-ip-address 0.0.0.0 --end-ip-address 0.0.0.0

echo "Allowing Firewall IP on Old PGSQL"
az postgres server firewall-rule create -g $RG -s $OLD_PGSQL -n allowiprange --start-ip-address 0.0.0.0 --end-ip-address 0.0.0.0
DMS_SUBNET_ID=$(az network vnet subnet list --resource-group $RG --vnet-name $VNET_NAME --query [].id -o tsv | grep DMSSubnet | head -n 1)
echo "DMS Subnet ID is: " $DMS_SUBNET_ID

az postgres server vnet-rule create -g $RG -s $OLD_PGSQL -n DMSSubnet --subnet $DMS_SUBNET_ID



echo "Creating DMS service now, it will take around 15 minutes."
az dms create -l $location -n $Service_Name -g $RG --sku-name $DMS_SKU_NAME --subnet $DMS_SUBNET_ID
sleep 5
echo "Creating project inside DMS."

az dms project create --location $location --name myproject --resource-group $RG --service-name $Service_Name --source-platform PostgreSQL --target-platform AzureDbForPostgreSQL


echo "List of Databases, you can ignore few of them...."
echo "List of database: "
#psql --host=$OLD_PGSQL".postgres.database.azure.com" --port=5432 --username=azureignio@$OLD_PGSQL  --list --table-attr= | awk '{print $1}' | sed 's/-//g' | sed 's/|//g'

psql --host=asuse11dopsq1pgsql.postgres.database.azure.com --port=5432 --username=azureignio@asuse11dopsq1pgsql --list --table-attr= | awk '{print $1}' | sed 's/-//g' | sed 's/|//g' | sed 's/postgres//g' | sed 's/azure_maintenance//' | sed 's/+//g' | sed 's/azure_sys//g' | sed 's/template0//g' | sed 's/template1//g' | sed 's/List//g' | sed 's/Name/DataBaseNAME/g'