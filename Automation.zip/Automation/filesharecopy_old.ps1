$fileShareName="amuse11storsafs"  
$directoryPath="data"  
$StorageAccountName = "amuse11storsa"
$StorageAccessKey = "md226fZvTKPKaCd9TxDGPn4mitCPfvBvgzElwoqIgpbf2Pe09GKKfNJlMcK2EXXqRLqOrhBslybaE1Cpz2BcPg=="
$context1=New-AzureStorageContext $StorageAccountName $StorageAccessKey
$DestStorageAccountName = "funcmi73qgdmjeosq"
$DestStorageAccessKey = "xZjU0r5g5fU+/ieAbwc22OmVtFY5BJdQuF8OZsFd7hGHYLzQFGg9ZCpsVnQi5u6Wi/nigb8jdupUGo0YaXBphg=="
$destcontext1=New-AzureStorageContext $DestStorageAccountName $DestStorageAccessKey
$SrcPath = "mountscript.sh"
$SrcShare = "amuse11storsafs"
$DestPath = "amuse11logsa01toamuse11logehns02func"
$DestShare = "amuse11logsa01toamuse11logehns02func"
$aaaa = (New-AzureStorageContext -StorageAccountName amuse11storsa -StorageAccountKey "md226fZvTKPKaCd9TxDGPn4mitCPfvBvgzElwoqIgpbf2Pe09GKKfNJlMcK2EXXqRLqOrhBslybaE1Cpz2BcPg==")
Function GetFiles  
{   
    $directories = (Get-AzureStorageFile -Context $aaaa -ShareName $fileShareName)
    foreach($directory in $directories)
    {
         if ($directory.Name -like "*.csv*") 
		 {
             Write-Output $directory 
			 Start-AzureStorageFileCopy -SrcFilePath $directory.Name -SrcShareName $SrcShare -DestShareName $DestShare -DestFilePath $directory.Name -Context $context1 -DestContext $destcontext1 -Force
		 }
         else {
			 write-host $directory
             $files = Get-AzureStorageFile -Context $aaaa -ShareName $fileShareName -Path $directory.Name | Get-AzureStorageFile -ErrorAction SilentlyContinue
                foreach ($file in $files)
				{
					if ($file.Name -like "*.csv*")
					{
						Write-Output $file
						$xy = $directory.Name + "/" + $file.Name
						Start-AzureStorageFileCopy -SrcFilePath $xy -SrcShareName $SrcShare -DestShareName $DestShare -DestFilePath $file.Name -Context $context1 -DestContext $destcontext1 -Force
					}

					else {
#					     write-host $file.Name
						 $bbbb = (New-AzureStorageContext -StorageAccountName amuse11storsa -StorageAccountKey "md226fZvTKPKaCd9TxDGPn4mitCPfvBvgzElwoqIgpbf2Pe09GKKfNJlMcK2EXXqRLqOrhBslybaE1Cpz2BcPg==")
						 $fileShareName="amuse11storsafs"
						 $a = $directory.Name
						 $b = $file.Name
						 $abconcat = $a + "/" + $b
						 $files_depth1 = (Get-AzureStorageFile -Context $bbbb -ShareName $fileShareName -Path $abconcat | Get-AzureStorageFile -ErrorAction SilentlyContinue)
						 foreach ($file1 in $files_depth1)
						 {
							if ($file1.Name -like "*.csv*")
							{
							Write-Output $file1
							$xyz = $a + "/" + $b + "/" + $file1.Name
							Start-AzureStorageFileCopy -SrcFilePath $xyz -SrcShareName $SrcShare -DestShareName $DestShare -DestFilePath $file1.Name -Context $context1 -DestContext $destcontext1 -Force
							}
						    else
							{
										$cccc = (New-AzureStorageContext -StorageAccountName amuse11storsa -StorageAccountKey "md226fZvTKPKaCd9TxDGPn4mitCPfvBvgzElwoqIgpbf2Pe09GKKfNJlMcK2EXXqRLqOrhBslybaE1Cpz2BcPg==")
										$fileShareName="amuse11storsafs"
										$c = $directory.Name
										$d = $file.Name
										$e = $file1.Name
										$cde = $c + "/" + $d + "/" + $e 
										$files_depth2 = (Get-AzureStorageFile -Context $cccc -ShareName $fileShareName -Path $cde | Get-AzureStorageFile -ErrorAction SilentlyContinue)
							foreach ($file2 in $files_depth2)
								{
									if ($file2.Name -like "*.csv*")
									{
#										Write-Output $file2
										$cdef = $c + "/" + $d + "/" + $e + "/" + $file2.Name
										Start-AzureStorageFileCopy -SrcFilePath $cdef -SrcShareName $SrcShare -DestShareName $DestShare -DestFilePath $file2.Name -Context $context1 -DestContext $destcontext1 -Force
									}
									else
									{
										$dddd = (New-AzureStorageContext -StorageAccountName amuse11storsa -StorageAccountKey "md226fZvTKPKaCd9TxDGPn4mitCPfvBvgzElwoqIgpbf2Pe09GKKfNJlMcK2EXXqRLqOrhBslybaE1Cpz2BcPg==")
										$fileShareName="amuse11storsafs"
										$f = $directory.Name
										$g = $file.Name
										$h = $file1.Name
										$i = $file2.Name
										$fghi = $f + "/" + $g + "/" + $h + "/" + $i
										$files_depth3 = (Get-AzureStorageFile -Context $dddd -ShareName $fileShareName -Path $fghi | Get-AzureStorageFile -ErrorAction SilentlyContinue)
										foreach ($file3 in $files_depth3)
										{
											if ($file3.Name -like "*.csv*")
											{
#												Write-Output $file3
												$fghif = $f + "/" + $g + "/" + $h + "/" + $i + "/" + $file3.Name
												Start-AzureStorageFileCopy -SrcFilePath $fghif -SrcShareName $SrcShare -DestShareName $DestShare -DestFilePath $file3.Name -Context $context1 -DestContext $destcontext1 -Force
											}
											else
											{
												$eeee = (New-AzureStorageContext -StorageAccountName amuse11storsa -StorageAccountKey "md226fZvTKPKaCd9TxDGPn4mitCPfvBvgzElwoqIgpbf2Pe09GKKfNJlMcK2EXXqRLqOrhBslybaE1Cpz2BcPg==")
												$fileShareName="amuse11storsafs"
												$j = $directory.Name
												$k = $file.Name
												$l = $file1.Name
												$m = $file2.Name
												$n = $file3.Name
												$jklmn = $j + "/" + $k + "/" + $l + "/" + $m + "/" + $n
												$files_depth4 = (Get-AzureStorageFile -Context $eeee -ShareName $fileShareName -Path $jklmn | Get-AzureStorageFile -ErrorAction SilentlyContinue)
												foreach ($file4 in $files_depth4)
												{
													if ($file4.Name -like "*.csv*")
													{
														Write-Output $file4
														$jklmnf = $j + "/" + $k + "/" + $l + "/" + $m + "/" + $n + "/" + $file4.Name
														Start-AzureStorageFileCopy -SrcFilePath $jklmnf -SrcShareName $SrcShare -DestShareName $DestShare -DestFilePath $file4.Name -Context $context1 -DestContext $destcontext1 -Force
													}
													else
													{
														$ffff = (New-AzureStorageContext -StorageAccountName amuse11storsa -StorageAccountKey "md226fZvTKPKaCd9TxDGPn4mitCPfvBvgzElwoqIgpbf2Pe09GKKfNJlMcK2EXXqRLqOrhBslybaE1Cpz2BcPg==")
														$fileShareName="amuse11storsafs"
														$o = $directory.Name
														$p = $file.Name
														$q = $file1.Name
														$r = $file2.Name
														$s = $file3.Name
														$t = $file4.Name
														$opqrst = $o + "/" + $p + "/" + $q + "/" + $r + "/" + $s + "/" + $t
														$files_depth5 = (Get-AzureStorageFile -Context $ffff -ShareName $fileShareName -Path $opqrst | Get-AzureStorageFile -ErrorAction SilentlyContinue)
														foreach ($file5 in $files_depth5)
															{
																if ($file5.Name -like "*.csv*")
																{
																	Write-Output $file5
																	$opqrstf = $o + "/" + $p + "/" + $q + "/" + $r + "/" + $s + "/" + $t + "/" + $file5.Name
																	Start-AzureStorageFileCopy -SrcFilePath $opqrstf -SrcShareName $SrcShare -DestShareName $DestShare -DestFilePath $file5.Name -Context $context1 -DestContext $destcontext1 -Force
																}
																else
																{
																	$gggg = (New-AzureStorageContext -StorageAccountName amuse11storsa -StorageAccountKey "md226fZvTKPKaCd9TxDGPn4mitCPfvBvgzElwoqIgpbf2Pe09GKKfNJlMcK2EXXqRLqOrhBslybaE1Cpz2BcPg==")
																	$fileShareName="amuse11storsafs"
																	$u = $directory.Name
																	$v = $file.Name
																	$w = $file1.Name
																	$x = $file2.Name
																	$y = $file3.Name
																	$z = $file4.Name
																	$za = $file5.Name
																	$uvwxyza = $u + "/" + $v + "/" + $w + "/" + $x + "/" + $y + "/" + $z + "/" + $za
																	$files_depth6 = (Get-AzureStorageFile -Context $gggg -ShareName $fileShareName -Path $uvwxyza | Get-AzureStorageFile -ErrorAction SilentlyContinue)
																	foreach ($file6 in $files_depth6)
																		{
																			Write-Output $file6
																			$uvwxyzaf = $u + "/" + $v + "/" + $w + "/" + $x + "/" + $y + "/" + $z + "/" + $za + "/" + $file6.Name
																			Start-AzureStorageFileCopy -SrcFilePath $uvwxyzaf -SrcShareName $SrcShare -DestShareName $DestShare -DestFilePath $file6.Name -Context $context1 -DestContext $destcontext1 -Force
																		}
																}
															}
													}
												}
											}
										}
									}
								}
							}
						 }
						 }
				}
         }
    }

}
  
GetFiles
