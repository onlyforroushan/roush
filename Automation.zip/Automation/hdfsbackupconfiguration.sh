#!/bin/sh
#Script to configure full and incremental backup.
mv /ignio/hdfs_backup/ /ignio/hdfs_backup_old_
echo "Creating the prerequisite directory with required permission"
mkdir -p /ignio/hdfs_backup
chmod -R 777 /ignio/hdfs_backup
chown -R hbase:hbase /ignio/hdfs_backup
touch /ignio/hdfs_backup/full_hadoop_backup.sh /ignio/hdfs_backup/incremental_hadoop_backup.sh /ignio/hdfs_backup/full_backup_all_tenants.sh /ignio/hdfs_backup/start_yarn_nodemanager.sh /ignio/hdfs_backup/tmp_cleanup.sh /ignio/hdfs_backup/start_yarn_resourcemanager.sh /ignio/log/incrbackuphbase.log /ignio/log/fullbackuphbase.log /ignio/log/backupcron.log
chmod 777 /ignio/hdfs_backup/full_hadoop_backup.sh /ignio/hdfs_backup/incremental_hadoop_backup.sh /ignio/hdfs_backup/full_backup_all_tenants.sh /ignio/hdfs_backup/start_yarn_nodemanager.sh /ignio/hdfs_backup/tmp_cleanup.sh /ignio/hdfs_backup/start_yarn_resourcemanager.sh /ignio/log/incrbackuphbase.log /ignio/log/fullbackuphbase.log /var/log/incrbackuphbase.log /var/log/fullbackuphbase.log /ignio/log/backupcron.log
chown hbase:hbase /ignio/hdfs_backup/full_hadoop_backup.sh /ignio/hdfs_backup/incremental_hadoop_backup.sh /ignio/hdfs_backup/full_backup_all_tenants.sh /ignio/hdfs_backup/start_yarn_nodemanager.sh /ignio/hdfs_backup/start_yarn_resourcemanager.sh
chown hdfs:hdfs /ignio/hdfs_backup/tmp_cleanup.sh



echo "files created and permission given."

cat > /ignio/hdfs_backup/full_hadoop_backup.sh <<- "EOF"
#!/bin/sh
#full backup
timestamp()
{
 date +"%Y-%m-%d %T.%3N"
}
source /home/hbase/.bashrc
tech="Hadoop"
backuptype="FullBackup"
namespace=$1
kinit
kinit -k -t $HBASE_HOME/etc/security/hbase.service.keytab hbase/"$HOSTNAME".inignio.com@$(cat /etc/krb5.conf | grep -m1 realm | cut -b 17-30)
kinit -k -t $HADOOP_HOME/etc/security/hdfs.service.keytab hdfs/"$HOSTNAME".inignio.com@$(cat /etc/krb5.conf | grep -m1 realm | cut -b 17-30)
DATE=`date '+%Y%m%d%H%M%S'`
if [ $? -eq 0 ]; then
        echo "$(timestamp)|${tech}|${backuptype}|INFO|/ignio/hdfs_backup/full_hadoop_backup.sh|Full Database Backup Started for tenant ${namespace} with current epocTime, i.e. $DATE"
else
    echo "$(timestamp)|${tech}|${backuptype}|ERROR|/ignio/hdfs_backup/full_hadoop_backup.sh|Full Database Backup Failed. Unable to update date"
        exit 1
fi
epocTime=`date +%s%3N`
#echo "$(timestamp)|${tech}|${backuptype}|INFO|/ignio/hdfs_backup/full_hadoop_backup.sh|New backup has been scheduled at:"
#echo "/bin/sh /ignio/hdfs_backup/full_hadoop_backup.sh ${namespace} >> /ignio/log/fullbackuphbase.log 2>&1" | at tomorrow
store_path=/ignio/hdfs_backup/${namespace}/backup/fullbackup/fullbackup_${DATE}
mkdir -p ${store_path}
mkdir -p /backup/${namespace}/backup/fullbackup/
mkdir -p /backup/${namespace}/backup/incbackup/
chmod -R 777 ${store_path}
echo "list '"$namespace":.*' " | $HBASE_HOME/bin/hbase shell &> /ignio/hdfs_backup/${namespace}/ListOutput
cat /ignio/hdfs_backup/${namespace}/ListOutput | grep "^"${namespace}":" >/ignio/hdfs_backup/${namespace}/ListOfTable
$HADOOP_HOME/bin/hdfs dfs -mkdir -p /backup/${namespace}/fullbackup_${DATE}  > /dev/null 2>&1
while read line; do
        tableName=`echo $line | cut -d':' -f2`
        $HBASE_HOME/bin/hbase org.apache.hadoop.hbase.mapreduce.Export $line hdfs:///backup/${namespace}/fullbackup_${DATE}/${tableName}/ 
if [ $? == 1 ]; then
   echo "$(timestamp)|${tech}|${backuptype}|INFO|/ignio/hdfs_backup/full_hadoop_backup.sh|$line Backed-Up Successfully"
else
echo "$(timestamp)|${tech}|${backuptype}|ERROR|/ignio/hdfs_backup/full_hadoop_backup.sh|$line Backup failed"
exit 1
fi
        $HADOOP_HOME/bin/hdfs dfs -chmod -R 777 /backup/${namespace}/fullbackup_${DATE}/ > /dev/null 2>&1
       $HADOOP_HOME/bin/hdfs dfs -get /backup/${namespace}/fullbackup_${DATE}/${tableName} ${store_path} > /dev/null 2>&1
done < /ignio/hdfs_backup/${namespace}/ListOfTable
echo "$(timestamp)|${tech}|${backuptype}|INFO|/ignio/hdfs_backup/full_hadoop_backup.sh|Backup completed successfully for ${namespace} at $DATE "
echo ${epocTime} > ${store_path}/epocTime
cp -r ${store_path} /backup/${namespace}/backup/fullbackup
sleep 5
$HADOOP_HOME/bin/hdfs dfs -rm -r /backup/${namespace}/fullbackup_${DATE}/ > /dev/null 2>&1
cd ${store_path}/../
rm -rf /ignio/hdfs_backup/${namespace}/backup/fullbackup/fullbackup_${DATE} > /dev/null 2>&1
cd /backup/${namespace}/backup/fullbackup
rm -rf `ls -t | awk 'NR>4'` > /dev/null 2>&1


EOF

cat > /ignio/hdfs_backup/incremental_hadoop_backup.sh <<- "EOF"
#!/bin/sh
#incremental backup
source /home/hbase/.bashrc
tech="Hadoop"
backuptype="IncrementalBackup"
timestamp()
{
 date +"%Y-%m-%d %T.%3N"
}
kinit -k -t $HBASE_HOME/etc/security/hbase.service.keytab hbase/"$HOSTNAME".inignio.com@$(cat /etc/krb5.conf | grep -m1 realm | cut -b 17-30)
namespace=$1
DATE=`date '+%Y%m%d%H%M%S'`
if [ $? -eq 0 ]; then
        echo "$(timestamp)|${tech}|${backuptype}|INFO|/ignio/hdfs_backup/incremental_hadoop_backup.sh|Database Backup Started for tenant ${namespace} with current epocTime, i.e. $DATE"
else
    echo "$(timestamp)|${tech}|${backuptype}|ERROR|/ignio/hdfs_backup/incremental_hadoop_backup.sh|Database Backup Failed. Unable to update date"
        exit 1
fi
epocTime=`date +%s%3N`
#echo "$(timestamp) | ${tech} | ${backuptype} | Info | Next incremental backup will start in 30 minutes, at:"
#echo "/bin/sh /ignio/hdfs_backup/incremental_hadoop_backup.sh ${namespace} >> /ignio/log/incrbackuphbase.log 2>&1" | at now + 55 minutes
i_store_path=/ignio/hdfs_backup/${namespace}/ibackup/incrementalbackup_${DATE}
#mkdir -p ${store_path}
mkdir -p ${i_store_path}
latest_directory=$(ls -td /backup/${namespace}/backup/fullbackup/*/ | head -n1)epocTime
startTime=$( cat $latest_directory )
#echo "$(timestamp)|${tech}|${backuptype}|INFO|/ignio/hdfs_backup/incremental_hadoop_backup.sh|Hi this is starting epoc time $startTime"
endTime=`date +%s%3N`
#echo "$(timestamp)|${tech}|${backuptype}|INFO|/ignio/hdfs_backup/incremental_hadoop_backup.sh|Hi this is ending epoc time $endTime"
echo "list '"$namespace":.*' " | $HBASE_HOME/bin/hbase shell &> /ignio/hdfs_backup/${namespace}/ListOutput
cat /ignio/hdfs_backup/${namespace}/ListOutput | grep "^"${namespace}":" >/ignio/hdfs_backup/${namespace}/ListOfTable
$HADOOP_HOME/bin/hdfs dfs -mkdir -p /backup/${namespace}/incBackup_${startTime}_${endTime}/ &> /dev/null
while read line; do
        tableName=`echo $line | cut -d':' -f2`

        $HBASE_HOME/bin/hbase org.apache.hadoop.hbase.mapreduce.Export $line hdfs:///backup/${namespace}/incBackup_${startTime}_${endTime}/${tableName}/ 1 $startTime $endTime &> /dev/null
        if [ $? == 1 ]; then
        echo "$(timestamp)|${tech}|${backuptype}|INFO|/ignio/hdfs_backup/incremental_hadoop_backup.sh|$line Backedup Successfully"
        else
        echo "$(timestamp)|${tech}|${backuptype}|ERROR|/ignio/hdfs_backup/incremental_hadoop_backup.sh|$line Backup failed"
        exit 1
        fi
        $HADOOP_HOME/bin/hdfs dfs -chmod -R 777 /backup/${namespace}/incBackup_${startTime}_${endTime}/ &> /dev/null
        $HADOOP_HOME/bin/hdfs dfs -get /backup/${namespace}/incBackup_${startTime}_${endTime}/${tableName} ${i_store_path} &> /dev/null
done < /ignio/hdfs_backup/${namespace}/ListOfTable
echo ${epocTime} > ${i_store_path}/epocTime
$HADOOP_HOME/bin/hdfs dfs -rm -r /backup/${namespace}/incBackup_${startTime}_${endTime}/ &> /dev/null
#echo "$(timestamp)|${tech}|${backuptype}|INFO|/ignio/hdfs_backup/incremental_hadoop_backup.sh|Incremental backup data will be stored at /backup/${namespace}/backup/incbackup/"
echo "$(timestamp)|${tech}|${backuptype}|INFO|/ignio/hdfs_backup/incremental_hadoop_backup.sh|Backup completed successfully for ${namespace} @ $endTime"
cp -r ${i_store_path} /backup/${namespace}/backup/incbackup
cd ${i_store_path}/..
rm -rf /ignio/hdfs_backup/${namespace}/ibackup/incrementalbackup_${DATE}
cd /backup/${namespace}/backup/fullbackup
rm -rf `ls -t | awk 'NR>8'`
cd /backup/${namespace}/backup/incbackup
rm -rf `ls -t | awk 'NR>4'`


EOF

cat > /ignio/hdfs_backup/full_backup_all_tenants.sh <<- "EOF"
#!/bin/sh
source /home/hbase/.bashrc
sleep 2
kinit -k -t $HBASE_HOME/etc/security/hbase.service.keytab hbase/"$HOSTNAME".inignio.com@$(cat /etc/krb5.conf | grep -m1 realm | cut -b 17-30)
kinit -k -t $HADOOP_HOME/etc/security/hdfs.service.keytab hdfs/"$HOSTNAME".inignio.com@$(cat /etc/krb5.conf | grep -m1 realm | cut -b 17-30)
echo "list_namespace" | $HBASE_HOME/bin/hbase shell &> /ignio/hdfs_backup/namespaceraw.txt
cat /ignio/hdfs_backup/namespaceraw.txt | grep rg | grep as | grep -v \/ > /ignio/hdfs_backup/namespace.txt
while read namespace; do
echo "Backing Up: "$namespace
/bin/sh /ignio/hdfs_backup/full_hadoop_backup.sh ${namespace} >> /ignio/log/fullbackuphbase.log
sleep 10
done < /ignio/hdfs_backup/namespace.txt

EOF

cat > /ignio/hdfs_backup/tmp_cleanup.sh <<- "EOF"
#!/bin/sh
source /home/hbase/.bashrc
echo "declaring time_stamp"
time_stamp=$(date +"%s-%d-%m-%Y")
echo $time_stamp
kinit -k -t $HADOOP_HOME/etc/security/hdfs.service.keytab hdfs/"$HOSTNAME".inignio.com@$(cat /etc/krb5.conf | grep -m1 realm | cut -b 17-30)
echo "CleanUp Started On $time_stamp "
#df -H | grep -vE '^Filesystem|tmpfs|cdrom' | awk '{ print $5 " " $1 }' | grep -v udev | while read output;
df -H | grep sdc1 | awk '{ print $5 " " $1 }' | while read output;
do
  echo $output
  usep=$(echo $output | awk '{ print $1}' | cut -d'%' -f1  )
  partition=$(echo $output | awk '{ print $2 }' )

  if [ $usep -ge 77 ]; then
    echo "Creating tar for all the dev/prod/test wp-content logs"
        $HADOOP_HOME/bin/hdfs dfs -rm -r /tmp/hadoop-yarn/staging/hbase/.staging
  else  
    echo "We won't do clean-up since space is less than 77%"
  fi
  
done

EOF

cat > /ignio/hdfs_backup/start_yarn_nodemanager.sh <<- "EOF"
#!/bin/sh
source /home/hbase/.bashrc
cp /home/hbase/.bashrc /home/yarn/.bashrc
source /home/yarn/.bashrc

nodemanager_count=$(jps | grep -i nodemanager | wc -l)

  if [ $nodemanager_count -ge 1 ]; then
    echo "nodemanager is already UP"
  else  
    sudo su - yarn -c '$HADOOP_HOME/sbin/yarn-daemon.sh start nodemanager'
	echo "Nodemanager was down, started now."
  fi


EOF

cat > /ignio/hdfs_backup/start_yarn_resourcemanager.sh <<- "EOF"
#!/bin/sh
source /home/hbase/.bashrc
cp /home/hbase/.bashrc /home/yarn/.bashrc
source /home/yarn/.bashrc

resourcemanager_count=$(jps | grep -i resourcemanager | wc -l)

  if [ $resourcemanager_count -ge 1 ]; then
    echo "Resourcemanager is already UP"
  else  
    sudo su - yarn -c '$HADOOP_HOME/sbin/yarn-daemon.sh start resourcemanager'
	echo "Resourcemanager was down, started now."
  fi


EOF

echo "copy start_yarn_resourcemanager.sh file to both namenodes and configure cron as root user, as we have done for this datanode. above file will check if yarn resourcemanager is up or not on the namenodes, periodically."

chmod -R 777 /ignio/hdfs_backup
chown -R hbase:hbase /ignio/hdfs_backup

echo "scheduling full backup and incremental backup now."

(crontab -l -u hbase 2>/dev/null; echo "00 04 * * * /bin/sh /ignio/hdfs_backup/full_backup_all_tenants.sh >> /ignio/log/backupcron.log") | crontab -u hbase -
(crontab -l -u hdfs 2>/dev/null; echo "40 03 * * * /bin/sh /ignio/hdfs_backup/tmp_cleanup.sh >> /ignio/log/backupcron.log") | crontab -u hdfs -
(crontab -l -u root 2>/dev/null; echo "30 03 * * * /bin/sh /ignio/hdfs_backup/start_yarn_nodemanager.sh >> /ignio/log/backupcron.log") | crontab -u root -


