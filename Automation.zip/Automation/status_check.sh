#!/bin/sh
COMMAND_NAME="yum -y install lynx"
COMMAND_NAME1="echo \"alias status='lynx \"https://\"\$(echo \$HOSTNAME | cut -c 1-8)\"chth01.inignio.com:8888\'\"\" >> /etc/profile.d/http_proxy.sh"
COMMAND_NAME2="echo \"alias status1='lynx \"https://\"\$(echo \$HOSTNAME | cut -c 1-8)\"chth01.inignio.com:8888\'\"\" >> /etc/profile.d/http_proxy.sh"
COMMAND_NAME3="echo \"alias status2='lynx \"https://\"\$(echo \$HOSTNAME | cut -c 1-8)\"chth02.inignio.com:8888\'\"\" >> /etc/profile.d/http_proxy.sh"
COMMAND_NAME4="echo \"alias status3='lynx \"https://\"\$(echo \$HOSTNAME | cut -c 1-8)\"chth03.inignio.com:8888\'\"\" >> /etc/profile.d/http_proxy.sh"
COMMAND_NAME5="echo \"alias status4='lynx \"https://\"\$(echo \$HOSTNAME | cut -c 1-8)\"chth04.inignio.com:8888\'\"\" >> /etc/profile.d/http_proxy.sh"


#COMMAND_NAME1="echo "alias status="lynx \"https://\"\$(echo \$HOSTNAME | cut -c 1-8)\"chth01.inignio.com:8888\""" >> /etc/profile.d/http_proxy.sh"
#COMMAND_NAME2="echo "alias status='lynx \"https://\"\$(echo \$HOSTNAME | cut -c 1-8)\"chth01.inignio.com:8888'\"" >> /etc/profile.d/http_proxy.sh"
#COMMAND_NAME3="echo "alias status='lynx \"https://\"\$(echo \$HOSTNAME | cut -c 1-8)\"chth01.inignio.com:8888'\"" >> /etc/profile.d/http_proxy.sh"
#COMMAND_NAME4="echo \"alias status='lynx \"https://\"\$(echo \$VM_NAME | cut -c 1-8)\"chth01.inignio.com:8888\'\"\" >> /etc/profile.d/http_proxy.sh"
#COMMAND_NAME5="echo \"alias status='lynx \"https://\"\$(echo \$HOSTNAME | cut -c 1-8)\"chth01.inignio.com:8888\'\"\" >> /etc/profile.d/http_proxy.sh"
#COMMAND_NAME6="echo "alias status='lynx \"https://\"\$(echo $HOSTNAME | cut -c 1-8)\"chth01.inignio.com:8888'\"" >> /etc/profile.d/http_proxy.sh"

subscriptionId=DigitateSaaSCustomer
echo "Subscription you chose is: " $subscriptionId
az account set --subscription $subscriptionId
#(az vm list --subscription $subscriptionId --query [].[name,resourceGroup] -o tsv | grep jump | grep -v amuse11rg) > /tmp/vm_rg.txt
while read -r line
do
case "$line" in \#*) continue ;; esac
VM_NAME=$(echo $line | awk '{print $1}')
RG_NAME=$(echo $line | awk '{print $2}')
echo ""
echo ""
echo ""
echo "Running command on VM/RG: " $VM_NAME $RG_NAME
az vm run-command invoke -g $RG_NAME -n $VM_NAME --command-id RunShellScript --scripts "$COMMAND_NAME && $COMMAND_NAME1 && $COMMAND_NAME2 && $COMMAND_NAME3 && $COMMAND_NAME4 && $COMMAND_NAME5"
echo ""
echo ""
echo ""
done < /tmp/vm_rg.txt