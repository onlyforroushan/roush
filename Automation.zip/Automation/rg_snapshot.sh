#!/bin/sh
rg=asuse11dopsq1rg

subscriptionId=0a2449ac-4fe3-4900-842b-d162e1d7bc09
az account set --subscription $subscriptionId
subscriptionName=DigitateSaaSInternal
snapshot_rg="${rg}SNAPSHOT"
disk_count=$(az disk list -g $rg --query "[].{Name:name}" --output tsv | wc -l)
disk_location=$(az disk list -g $rg --query "[0].{Name:location}" --output tsv)

az group create --location $disk_location --name $snapshot_rg --subscription $subscriptionName

for (( c=0; c<$disk_count; c++ ))
do  
   NOW=$(date +"%m-%d-%Y")
   snapshot_name="$(az disk list -g $rg --query "[$c].{Name:name}" --output tsv)$NOW"
   id_name="$(az disk list -g $rg --query "[$c].{Name:id}" --output tsv)"
   echo $snapshot_name
   echo $id_name
   az snapshot create -g $snapshot_rg -n $snapshot_name --source $id_name
   
done

