#!/bin/sh

time_stamp=$(date +"%s-%d-%m-%Y")

echo "CleanUp Started On $time_stamp "

echo "Creating tar for all the dev/prod/test wp-content logs"
tar -zcf /var/www/btcwedprd/wp-content/cache/log/000000-$(date +"%s-%d-%m-%Y").tar.gz /var/www/btcwedprd/wp-content/cache/log/000000
tar -zcf /var/www/btcweddev/wp-content/cache/log/000000-$(date +"%s-%d-%m-%Y").tar.gz /var/www/btcweddev/wp-content/cache/log/000000
tar -zcf /var/www/btcwedtst/wp-content/cache/log/000000-$(date +"%s-%d-%m-%Y").tar.gz /var/www/btcwedtst/wp-content/cache/log/000000

echo "Emptying (Not Deleting) btcwedprd logs"
echo "" > /var/www/btcwedprd/wp-content/cache/log/000000/minify.log
echo "" > /var/www/btcwedprd/wp-content/cache/log/000000/varnish.log
echo "" > /var/www/btcwedprd/wp-content/cache/log/000000/pagecache.log
echo "" > /var/www/btcwedprd/wp-content/cache/log/000000/objectcache-calls.log
echo "" > /var/www/btcwedprd/wp-content/cache/log/000000/dbcache.log
echo "" > /var/www/btcwedprd/wp-content/cache/log/000000/dbcache-queries.log

echo "Emptying (Not Deleting) btcweddev logs"
echo "" > /var/www/btcweddev/wp-content/cache/log/000000/minify.log
echo "" > /var/www/btcweddev/wp-content/cache/log/000000/varnish.log
echo "" > /var/www/btcweddev/wp-content/cache/log/000000/pagecache.log
echo "" > /var/www/btcweddev/wp-content/cache/log/000000/objectcache-calls.log
echo "" > /var/www/btcweddev/wp-content/cache/log/000000/dbcache.log
echo "" > /var/www/btcweddev/wp-content/cache/log/000000/dbcache-queries.log

echo "Emptying (Not Deleting) btcwedtst log"
echo "" > /var/www/btcwedtst/wp-content/cache/log/000000/minify.log
echo "" > /var/www/btcwedtst/wp-content/cache/log/000000/varnish.log
echo "" > /var/www/btcwedtst/wp-content/cache/log/000000/pagecache.log
echo "" > /var/www/btcwedtst/wp-content/cache/log/000000/objectcache-calls.log
echo "" > /var/www/btcwedtst/wp-content/cache/log/000000/dbcache.log
echo "" > /var/www/btcwedtst/wp-content/cache/log/000000/dbcache-queries.log

echo "delete tar older than 30 days"
find /var/www/btcwedprd/wp-content/cache/log/000000-* -mtime +30 -exec rm {} \;
find /var/www/btcweddev/wp-content/cache/log/000000-* -mtime +30 -exec rm {} \;
find /var/www/btcwedtst/wp-content/cache/log/000000-* -mtime +30 -exec rm {} \;

echo "delete apache tar.gz older than 30 days"
find /var/log/apache2/ -name '*.log*.gz*' -mtime +30 -exec rm {} \;


echo "CleanUp Finished On $time_stamp "