###############################################GETTING USER INPUT#############################################
$rg_name = "asuse11dopsq1rg"
$dr_location = "westus"
##############################################################################################################



###############################################SETTING SUBSCRIPTION#############################################
clear
Select-AzureRmSubscription -SubscriptionName DigitateSaasInternal
##############################################################################################################


################################Creating DR_RG/STORAGE_ACCOUNT/CONTAINER########################################
$dr = "dr"
$STORAGE = "storage"
$dr_rg_name = $rg_name+$dr
$storageAccountName = $dr_rg_name+$STORAGE
New-AzureRmResourceGroup -Name $dr_rg_name -Location $dr_location -Force
Start-Sleep -s 2
New-AzureRmStorageAccount -ResourceGroupName $dr_rg_name -Name $storageAccountName -Location $dr_location -SkuName Standard_RAGRS -Kind StorageV2
Start-Sleep -s 2
$destContainer = "drcontainer"
$context = (Get-AzStorageAccount -ResourceGroupName $dr_rg_name -AccountName $storageAccountName).context
New-AzureRmStorageContainer -Name $destContainer -StorageAccountName $storageAccountName -ResourceGroupName $dr_rg_name
##############################################################################################################


$vmInfo = Get-AzureRmVM -ResourceGroupName $rg_name
$VMlists = $vmInfo.Name
Write-Host "Hey Greetings !! Sit Back and relax . " -ForegroundColor Cyan 
Start-Sleep -s 1
$i = 1

ForEach($VMlist in $VMlists)
{
Write-Host "I have started my work with $VMlist VM . And this is No:$i VM in List ." -ForegroundColor Cyan 
Start-Sleep -s 1
$VMName = $VMlist
#$rg_name = (Get-AzureRmResource -Name $VMName -ResourceType "Microsoft.Compute/virtualMachines").ResourceGroupName
$OSDisks = (Get-AzureRMVM –Name $VMName –ResourceGroupName $rg_name).StorageProfile.OsDisk.Name
$DataDisks = (Get-AzureRMVM –Name $VMName –ResourceGroupName $rg_name).StorageProfile.DataDisks.name
$i = 1

ForEach($OSDisk in $OSDisks)
{
Write-Host "OS-Disk No $i is : $OSDisk"
Write-Host "Now I am creating snapshot of OSDisk $i " -ForegroundColor White
$Disk = Get-AzureRmDisk -ResourceGroupName $rg_name -Name $OSDisk
$location = (Get-AzureRmResource -Name $OSDisk).Location
$day = (Get-Date).Day
$month = Get-Date -Format MMM
$year = (Get-Date).Year
$OSSnapshotName = ($VMName + '_' + $day + '_' + $month + '_' + $year + '_Snapshot_OS_Disk_' + $i)
$Snapshot = New-AzureRmSnapshotConfig -SourceUri $Disk.Id -CreateOption Copy -Location $location
New-AzureRmSnapshot -Snapshot $Snapshot -SnapshotName $OSSnapshotName -ResourceGroupName $dr_rg_name | Out-Null
Write-Host "Snapshot Name : $OSSnapshotName" -ForegroundColor Green
Start-Sleep -s 4


#Move Snap to storage account 
$blobName = $OSSnapshotName
#Mention storage account Name
$storageAccountRGName = (Get-AzureRmResource -Name $storageAccountName -ResourceType "Microsoft.Storage/storageAccounts").ResourceGroupName
$storageAccountKey = (Get-AzureRmStorageAccountKey -ResourceGroupName $storageAccountRGName -Name $storageAccountName).Value | Select-Object -First 1
$SnapshotAccessURL = (Grant-AzureRMSnapshotAccess -ResourceGroupName $dr_rg_name -SnapshotName $blobName -Access 'Read' -DurationInSecond 172800).AccessSAS
$absoluteUri = $SnapshotAccessURL
$destContext = New-AzureStorageContext –StorageAccountName $storageAccountName -StorageAccountKey $storageAccountKey
Start-AzureStorageBlobCopy -AbsoluteUri $absoluteUri -DestContainer $destContainer -DestContext $destContext -DestBlob $blobName -Force
Start-Sleep -s 5
Write-Host "I have moved This $OSSnapshotName to storage account ." -ForegroundColor Green
$i =$i+1

}

$i = 1
ForEach($DataDisk in $DataDisks)
{
Write-Host "Data-Disk No $i is : $DataDisk"
Write-Host "Now I am creating snapshot of Data Disk $i " -ForegroundColor White
$Disk = Get-AzureRmDisk -ResourceGroupName $rg_name -Name $DataDisk
$location = (Get-AzureRmResource -Name $DataDisk).Location
$day = (Get-Date).Day
$month = Get-Date -Format MMM
$year = (Get-Date).Year
$DataSnapshotName = ($VMName + '_' + $day + '_' + $month + '_' + $year + '_Snapshot_Data_Disk_' + $i)
$Snapshot = New-AzureRmSnapshotConfig -SourceUri $Disk.Id -CreateOption Copy -Location $location
New-AzureRmSnapshot -Snapshot $Snapshot -SnapshotName $DataSnapshotName -ResourceGroupName $dr_rg_name | Out-Null
Write-Host "Snapshot Name : $DataSnapshotName" -ForegroundColor Green
Start-Sleep -s 10


#Move Snap to storage account 
$blobName = $DataSnapshotName
#Mention storage account Name

$storageAccountRGName = (Get-AzureRmResource -Name $storageAccountName -ResourceType "Microsoft.Storage/storageAccounts").ResourceGroupName
$storageAccountKey = (Get-AzureRmStorageAccountKey -ResourceGroupName $storageAccountRGName -Name $storageAccountName).Value | Select-Object -First 1
$SnapshotAccessURL = (Grant-AzureRMSnapshotAccess -ResourceGroupName $dr_rg_name -SnapshotName $blobName -Access 'Read' -DurationInSecond 172800).AccessSAS
$absoluteUri = $SnapshotAccessURL
$destContext = New-AzureStorageContext –StorageAccountName $storageAccountName -StorageAccountKey $storageAccountKey
Start-AzureStorageBlobCopy -AbsoluteUri $absoluteUri -DestContainer $destContainer -DestContext $destContext -DestBlob $blobName -Force
Start-Sleep -s 2
Write-Host "I have moved This $DataSnapshotName to storage account ." -ForegroundColor Green
$i ++

}
}