#!/bin/sh
#az login
read -p "Please enter 'Y' if login was successful. " -n 1 -r
echo -e ""
if [[ ! $REPLY =~ ^[Yy]$ ]]
then
    exit 1
fi
echo -e ""
echo "Enter 1 for DigitateSaaS (7fda1fea-1ecc-4a7f-8e44-d9de4130541e) Subscription"
echo "Enter 2 for DigitateSaaSInternal (0a2449ac-4fe3-4900-842b-d162e1d7bc09) Subscription"
echo "Enter 3 for DigitateSaaSDemo (e01e2545-a86a-4313-9816-e36ae1a23a07) Subscription"
echo "Enter 4 for DigitateSaaSCP (4120e5f7-d243-428d-ad7f-b5c7f5ce37ea) Subscription"
read NUMBER
case "$NUMBER" in		
   "1") subscriptionId="7fda1fea-1ecc-4a7f-8e44-d9de4130541e"
   ;;
   "2") subscriptionId="0a2449ac-4fe3-4900-842b-d162e1d7bc09"
   ;;
   "3") subscriptionId="e01e2545-a86a-4313-9816-e36ae1a23a07"
   ;;
   "4") subscriptionId="4120e5f7-d243-428d-ad7f-b5c7f5ce37ea"
   ;;
esac
echo "Subscription ID  you chose is: " $subscriptionId
az account set --subscription $subscriptionId
echo "Enter RG: "
read RG
echo "RG is: " $RG
CONCAT_RG=${RG::-2}
VNET_NAME=$CONCAT_RG"vnet"
echo "VNET is: " $VNET_NAME
OLD_PGSQL=$CONCAT_RG"pgsql"
echo "OLD PGSQL is: " $OLD_PGSQL
NEW_PGSQL=$CONCAT_RG"pgsql""11"
echo "NEW PGSQL is: " $NEW_PGSQL
adminuser=azureignio
echo "Admin User is: " $adminuser
adminpassword=PW4dopsqazuredb
echo "Admin password is: " $adminpassword
PGSQL_SKU=MO_Gen5_2
echo "SKU for pgsql will be: " $PGSQL_SKU
PGSQL_Version=11
echo "Version for pgsql will be: " $PGSQL_Version
location=$(az postgres server list -g $RG --query "[?name=='$OLD_PGSQL'].{Name:name,  admin:location}" -o tsv | awk '{print $2}')
echo "Location is: " $location
#location=$(az group list --query "[?name=='$RG']" -o tsv | awk '{print $2}')
#echo "Location is: " $location
time_variable=$(date +"%H_%M")
Service_Name="$RG$time_variable"
echo "Your new DMS service will be: " $Service_Name
DMS_SKU_NAME=Premium_4vCores
echo "DMS SKU will be: " $DMS_SKU_NAME
igniodatabase=$(psql --host=$OLD_PGSQL".postgres.database.azure.com" --port=5432 --username=azureignio@$OLD_PGSQL  --list --table-attr=| awk '{print $1}' | grep ignio2)

echo "Migration will take place on database: " $igniodatabase

#VNET_NAME=$(az network vnet list -g $RG --query '[].name' -o tsv | head -n 1)
#echo "VNET is: " $VNET_NAME
MGT_SUBNET_ID=$(az network vnet subnet list --resource-group $RG --vnet-name $VNET_NAME --query [].id -o tsv | grep mgt | head -n 1)
echo "MGT Subnet ID is: " $MGT_SUBNET_ID
SUBNET_ID=$(az network vnet subnet list --resource-group $RG --vnet-name $VNET_NAME --query [].id -o tsv | grep -v agw)
echo "Subnet IDs are: "
echo $SUBNET_ID

Available_IP=$(az network vnet show -g $RG -n $VNET_NAME --query addressSpace.addressPrefixes -o tsv)
Available_IP_Prefix=${Available_IP%.*}
echo "Your IP Address prefix will be: " $Available_IP_Prefix

read -p "Please enter 'Y' if above value is correct, else exit. " -n 1 -r
echo -e ""
if [[ ! $REPLY =~ ^[Yy]$ ]]
then
    exit 1
fi

echo "Creating subnet with the name as DMSSubnet."
az network vnet subnet create -n DMSSubnet --vnet-name asuse11dopsq1vnet -g asuse11dopsq1rg --address-prefixes "$Available_IP_Prefix.0/28"
sleep 10
echo "Creating PGSQL-11"
az postgres server create --resource-group $RG --name $NEW_PGSQL --location $location --admin-user $adminuser --admin-password $adminpassword --sku-name $PGSQL_SKU --version $PGSQL_Version --geo-redundant-backup Enabled --storage-size 512000 --backup-retention 7 --auto-grow Disabled --ssl-enforcement Enabled --public-network-access Enabled

i=1
rulename=subnetrulenumber
while IFS= read -r line
do
   echo "Updating Subnet ID: " $line
   rule=$rulename$i
   az postgres server vnet-rule create -g $RG -s $NEW_PGSQL -n $rule --subnet $line
   i=$(($i + 1))
done <<< "$SUBNET_ID"

echo "Allowing Firewall IP"
az postgres server firewall-rule create -g $RG -s $NEW_PGSQL -n allowiprange --start-ip-address 0.0.0.0 --end-ip-address 0.0.0.0

read -p "Please enter 'Y' if postgres created and configured successfully, else exit. " -n 1 -r
echo -e ""
if [[ ! $REPLY =~ ^[Yy]$ ]]
then
    exit 1
fi


DMS_SUBNET_ID=$(az network vnet subnet list --resource-group $RG --vnet-name $VNET_NAME --query [].id -o tsv | grep DMSSubnet | head -n 1)
echo "DMS Subnet ID is: " $DMS_SUBNET_ID

echo "Creating DMS service now, it will take around 15 minutes."
az dms create -l $location -n $Service_Name -g $RG --sku-name $DMS_SKU_NAME --subnet $DMS_SUBNET_ID
sleep 5
echo "Creating project inside DMS."

az dms project create --location $location --name myproject --resource-group $RG --service-name $Service_Name --source-platform PostgreSQL --target-platform AzureDbForPostgreSQL
echo "List of database: "
psql --host=$OLD_PGSQL".postgres.database.azure.com" --port=5432 --username=azureignio@$OLD_PGSQL  --list --table-attr= | awk '{print $1}' | sed 's/-//g' | sed 's/|//g'


echo "creating database on new postgresql-11"
echo "CREATE DATABASE $igniodatabase;" | psql --host=$NEW_PGSQL".postgres.database.azure.com" --port=5432 --username=azureignio@$NEW_PGSQL --dbname=postgres

rm -rf igniodatabase.sql
echo "Creating dump of database: " $igniodatabase
pg_dump -h $OLD_PGSQL".postgres.database.azure.com" -U azureignio@$OLD_PGSQL -d $igniodatabase -s > igniodatabase.sql
rm -rf igniodatabase.sql
pg_dump -h asuse11dopsq1pgsql.postgres.database.azure.com -U azureignio@asuse11dopsq1pgsql -d ignio2dopsq1 -s > igniodatabase.sql
psql -h asuse11dopsq1pgsql11.postgres.database.azure.com -U azureignio@asuse11dopsq1pgsql11 -d ignio2dopsq1 < igniodatabase.sql

azureignio@asuse11dopsq1pgsql
echo "Restoring the Schema: "
psql -h $NEW_PGSQL".postgres.database.azure.com" -U azureignio@$NEW_PGSQL -d $igniodatabase < igniodatabase.sql

echo "Getting Drop Foreign Key Query."

echo "SELECT Q.table_name
    ,CONCAT('ALTER TABLE ', table_schema, '.', table_name, STRING_AGG(DISTINCT CONCAT(' DROP CONSTRAINT ', foreignkey), ','), ';') as DropQuery
        ,CONCAT('ALTER TABLE ', table_schema, '.', table_name, STRING_AGG(DISTINCT CONCAT(' ADD CONSTRAINT ', foreignkey, ' FOREIGN KEY (', column_name, ')', ' REFERENCES ', foreign_table_schema, '.', foreign_table_name, '(', foreign_column_name, ')' ), ','), ';') as AddQuery
FROM
    (SELECT
    S.table_schema,
    S.foreignkey,
    S.table_name,
    STRING_AGG(DISTINCT S.column_name, ',') AS column_name,
    S.foreign_table_schema,
    S.foreign_table_name,
    STRING_AGG(DISTINCT S.foreign_column_name, ',') AS foreign_column_name
FROM
    (SELECT DISTINCT
    tc.table_schema,
    tc.constraint_name AS foreignkey,
    tc.table_name,
    kcu.column_name,
    ccu.table_schema AS foreign_table_schema,
    ccu.table_name AS foreign_table_name,
    ccu.column_name AS foreign_column_name
    FROM information_schema.table_constraints AS tc
    JOIN information_schema.key_column_usage AS kcu ON tc.constraint_name = kcu.constraint_name AND tc.table_schema = kcu.table_schema
    JOIN information_schema.constraint_column_usage AS ccu ON ccu.constraint_name = tc.constraint_name AND ccu.table_schema = tc.table_schema
WHERE constraint_type = 'FOREIGN KEY'
    ) S
    GROUP BY S.table_schema, S.foreignkey, S.table_name, S.foreign_table_schema, S.foreign_table_name
    ) Q
    GROUP BY Q.table_schema, Q.table_name; " | psql --host=$NEW_PGSQL".postgres.database.azure.com" --port=5432 --username=azureignio@$NEW_PGSQL --dbname=$igniodatabase > dropforeignkey.txt

awk '{ print $3,$4,$5,$6,$7,$8 }' dropforeignkey.txt 
awk '{ print $3,$4,$5,$6,$7,$8 }' dropforeignkey.txt > realdropforeignkey.txt
echo "Execute above query on newly creatd database."
