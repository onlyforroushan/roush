#!/bin/sh
#incremental backup
tech="Hadoop"
backuptype="IncrementalBackup"

timestamp()
{
 date +"%Y-%m-%d %T.%3N"
}

kinit -k -t /ignio/hbase/etc/security/hbase.service.keytab hbase/"$HOSTNAME".inignio.com@$(cat /etc/krb5.conf | grep -m1 realm | cut -b 17-30)
namespace=$1
DATE=`date '+%Y%m%d%H%M%S'`

if [ $? -eq 0 ]; then
        echo "$(timestamp)|${tech}|${backuptype}|INFO|/ignio/hdfs_backup/incremental_hadoop_backup.sh|Database Backup Started for tenant ${namespace} with current epocTime, i.e. $DATE"
else
    echo "$(timestamp)|${tech}|${backuptype}|ERROR|/ignio/hdfs_backup/incremental_hadoop_backup.sh|Database Backup Failed. Unable to update date"
        exit 1
fi

epocTime=`date +%s%3N`
#echo "$(timestamp) | ${tech} | ${backuptype} | Info | Next incremental backup will start in 30 minutes, at:"
echo "/bin/sh /ignio/hdfs_backup/incremental_hadoop_backup.sh ${namespace} >> /ignio/log/incrbackuphbase.log 2>&1" | at now + 55 minutes
i_store_path=/ignio/hdfs_backup/${namespace}/ibackup/incrementalbackup_${DATE}
#mkdir -p ${store_path}
mkdir -p ${i_store_path}

latest_directory=$(ls -td /backup/${namespace}/backup/fullbackup/*/ | head -n1)epocTime
startTime=$( cat $latest_directory )
#echo "$(timestamp)|${tech}|${backuptype}|INFO|/ignio/hdfs_backup/incremental_hadoop_backup.sh|Hi this is starting epoc time $startTime"
endTime=`date +%s%3N`
#echo "$(timestamp)|${tech}|${backuptype}|INFO|/ignio/hdfs_backup/incremental_hadoop_backup.sh|Hi this is ending epoc time $endTime"

echo "list '"$namespace":.*' " | /ignio/hbase/bin/hbase shell &> /ignio/hdfs_backup/${namespace}/ListOutput
cat /ignio/hdfs_backup/${namespace}/ListOutput | grep "^"${namespace}":" >/ignio/hdfs_backup/${namespace}/ListOfTable

/ignio/hadoop-hdfs/bin/hdfs dfs -mkdir -p /backup/${namespace}/incBackup_${startTime}_${endTime}/ &> /dev/null

while read line; do
        tableName=`echo $line | cut -d':' -f2`
        /ignio/hbase/bin/hbase org.apache.hadoop.hbase.mapreduce.Export $line hdfs:///backup/${namespace}/incBackup_${startTime}_${endTime}/${tableName}/ 1 $startTime $endTime &> /dev/null
        if [ $? == 1 ]; then
        echo "$(timestamp)|${tech}|${backuptype}|INFO|/ignio/hdfs_backup/incremental_hadoop_backup.sh|$line Backedup Successfully"
        else
        echo "$(timestamp)|${tech}|${backuptype}|ERROR|/ignio/hdfs_backup/incremental_hadoop_backup.sh|$line Backup failed"
        exit 1
        fi
        /ignio/hadoop-hdfs/bin/hdfs dfs -chmod -R 777 /backup/${namespace}/incBackup_${startTime}_${endTime}/ &> /dev/null
        /ignio/hadoop-hdfs/bin/hdfs dfs -get /backup/${namespace}/incBackup_${startTime}_${endTime}/${tableName} ${i_store_path} &> /dev/null

done < /ignio/hdfs_backup/${namespace}/ListOfTable
echo ${epocTime} > ${i_store_path}/epocTime

/ignio/hadoop-hdfs/bin/hdfs dfs -rm -r /backup/${namespace}/incBackup_${startTime}_${endTime}/ &> /dev/null

#echo "$(timestamp)|${tech}|${backuptype}|INFO|/ignio/hdfs_backup/incremental_hadoop_backup.sh|Incremental backup data will be stored at /backup/${namespace}/backup/incbackup/"
echo "$(timestamp)|${tech}|${backuptype}|INFO|/ignio/hdfs_backup/incremental_hadoop_backup.sh|Backup completed successfully for ${namespace} @ $endTime"

cp -r ${i_store_path} /backup/${namespace}/backup/incbackup
cd ${i_store_path}/..
rm -rf /ignio/hdfs_backup/${namespace}/ibackup/incrementalbackup_${DATE}
cd /backup/${namespace}/backup/fullbackup
rm -rf `ls -t | awk 'NR>8'`
cd /backup/${namespace}/backup/incbackup
rm -rf `ls -t | awk 'NR>4'`


