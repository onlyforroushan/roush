#!/bin/sh

echo "declaring time_stamp"
time_stamp=$(date +"%s-%d-%m-%Y")
echo $time_stamp
echo "/bin/sh /ignio/hdfs_backup/tmp_cleanup.sh" | at tomorrow
kinit -k -t /ignio/hadoop-hdfs/etc/security/hdfs.service.keytab hdfs/"$HOSTNAME".inignio.com@$(cat /etc/krb5.conf | grep -m1 realm | cut -b 17-30)

echo "CleanUp Started On $time_stamp "
#df -H | grep -vE '^Filesystem|tmpfs|cdrom' | awk '{ print $5 " " $1 }' | grep -v udev | while read output;

df -H | grep sdc1 | awk '{ print $5 " " $1 }' | while read output;
do
  echo $output
  usep=$(echo $output | awk '{ print $1}' | cut -d'%' -f1  )
  partition=$(echo $output | awk '{ print $2 }' )
  if [ $usep -ge 80 ]; then
    echo "Creating tar for all the dev/prod/test wp-content logs"
	/ignio/hadoop-hdfs/bin/hdfs dfs -rm -r /tmp/hadoop-yarn/staging/hbase/.staging
  else  
    echo "We won't do clean-up since space is less than 80%"
  
  fi
done